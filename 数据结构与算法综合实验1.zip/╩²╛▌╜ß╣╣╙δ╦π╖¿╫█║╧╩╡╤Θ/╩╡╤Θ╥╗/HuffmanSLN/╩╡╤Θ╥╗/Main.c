#include<stdio.h>
#include "Huffman.h"
#include"Compress.h"

void init_file(char filename[],int weight[])
{
	
	int ch;
	FILE* fp = fopen(filename, "rb");
	while ((ch = getc(fp)) != EOF)
	{
		weight[ch]++;
	}
	fclose(fp);
}

int main()
{
	HEAD head;
	int nSize;
	char* pBuffer;
	Huffmantree pHT;
	Huffmancode pHC;
	printf("=========Huffman文件压缩=========\n");
	printf("请输入文件名：");
	char filename[100];
	(void)scanf("%s", filename);
	int weight[256] = { 0 };
	init_file(filename, weight);		//获取各字节权重
	pHT=Tree(weight, 256);				//生成哈夫曼树
	pHC = Huffmancoding(pHT, 256,511);	//生成编码
	//TextHuffTree(pHT);				//输出树

	//TestHufCode(511, pHT, pHC);		//输出编码
	
	Compress(filename,&pBuffer, weight, pHC,&nSize);//压缩文件
	//Testcode(pBuffer);					//输出压缩后文件编码
	InitHead(filename, &head);
	WriteFile(filename, head, pBuffer, nSize);
	
	return 0;
}