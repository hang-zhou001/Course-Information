
#include "Huffman.h"
#include"Compress.h"
#include<string.h>
#include<stdlib.h>
#include<stdio.h>

int Compress(const char* pFilename, char**pBuffer,int weight[],Huffmancode cHC,int *Size)
{
	int nSize = 0;
	for (int i = 1; i <= 256; i++)
	{
		nSize += weight[i-1] * strlen(cHC[i]);		//计算文件总长度
	}
	nSize = (nSize % 8==0) ? (nSize / 8 ) : (nSize / 8+1);	//计算压缩后文件长度
	Encode(pFilename,pBuffer, cHC, nSize);			//压缩文件
	
	*Size=nSize;
	return 0;
}

char Str2Byte(const char* pBinStr)
{
	char b = 0x00;
	for (int i = 0; i < 8; i++)
	{
		
		b = b << 1;				//向右移位
		if (pBinStr[i] == '1')
		{
			b = b | 0x01;		
		}
		
	}
	return b;
}


int Encode(const char* pFilename,char**pBuffer, const Huffmancode pHC, int nSize)
{
	FILE* fp = fopen(pFilename, "rb");
	char cd[256] = { 0 };
	char* Buffer;
	Buffer = (char*)malloc(nSize * sizeof(char));
	if (Buffer == NULL)
		return 0;
	*pBuffer=Buffer;
	int pos = 0;
	int ch;
	while ((ch = getc(fp)) != EOF)
	{
		strcat(cd, pHC[ch+1]);				//将编码连接到cd数组中
		while (strlen(cd) >= 8)
		{
		
			Buffer[pos++] = Str2Byte(cd);	//将8位字符转化位一位储存
			for (int i = 0; i < 256 - 8; i++)
			{
				cd[i] = cd[i + 8];			//数组数据整体前移8位
			}
		}
		
	}
		if (strlen(cd) > 0)
		{
			Buffer[pos++] = Str2Byte(cd);	//最后不满8位按8位存储
		}
	fclose(fp);
	
	return 0;
}


int InitHead(char* filename, HEAD* head)
{
	strcpy(head->type, filename);
	head->length = 0;
	for (int i = 0; i < 256; i++)
	{
		head->weight[i] = 0;		//初始化
	}
	FILE* fp = fopen(filename, "rb");
	int ch;
	while ((ch = getc(fp) != EOF))
	{
		head->weight[ch]++;			//获取权值
		head->length++;				//获取原文件长度
	}
	fclose(fp);
	return 0;
}

void WriteFile(char* filename, HEAD head, char* pBuffer, int nSize)
{
	char pFilename[256] = { 0 };
	strcpy(pFilename, filename);
	strcat(pFilename, ".huf");

	FILE* out = fopen(pFilename, "wb");
	fwrite(&head, sizeof(HEAD), 1, out);
	fwrite(pBuffer, sizeof(char), nSize, out);
	fclose(out);
	int len = sizeof(HEAD) + strlen(pFilename) + 1 + nSize;
	printf("%d字节\n", head.length);
	printf("生成压缩文件：%s\n", pFilename);
	printf("%d字节\n", len);
	printf("压缩比率：%.4lf%%", len / (head.length * 1.0)*100);
}


