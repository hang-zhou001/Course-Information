#pragma once
#define true 1
#define false 0

//用于构建二叉树
typedef struct                   //树的结点存储结构
{
	int weight;                  //结点的权值
	int parent, lchild, rchild;  //结点的双亲、左孩子和右孩子结点
}HTnode, * Huffmantree;

//用于先序遍历二叉树储存结点信息
typedef struct               //栈的存储结构
{
	int* base;               //栈底指针
	int* top;                //栈顶指针
	int stacksize;           //栈的大小
}Stack;


//储存两个最小权值点
typedef struct
{
	int s1;
	int s2;
}Mincode;



typedef char** Huffmancode;

//生成哈夫曼树
Huffmantree Tree(int *w, int n);

//先序遍历生成编码
Huffmancode Huffmancoding(Huffmantree HT, int n, int root);

//从当前节点中选出权值最小的两个节点
void Select(Huffmantree HT, int n, Mincode* code);

//输出哈夫曼树
void TextHuffTree(Huffmantree pHT);



//输出每个叶子节点的编码
void TestHufCode(int root, Huffmantree pHT, Huffmancode pHC);

//输出压缩后文件的编码
void Testcode(char* pBuffer);

//用栈进行先序遍历
void InitStack(Stack* s);
void Push(Stack* s, int e);
void Pop(Stack* s, int* e);
int StackEmpty(Stack s);