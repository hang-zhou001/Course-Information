#pragma once
#include"Huffman.h"


typedef struct HEAD
{
	char type[4];			//文件名
	int length;				//文件长度
	int weight[256];		//权值
}HEAD;

//压缩编码
int Compress(const char* pFilename, char** pBuffer, int weight[], Huffmancode cHC, int* Size);

//将8位字符转换成一位字符
char Str2Byte(const char* pBinStr);

//压缩编码
int Encode(const char* pFilename, char** pBuffer,const Huffmancode pHC, int nSize);

//获取原文件长度、名称
int InitHead(char* filename, HEAD* head);

//将压缩后的编码写入文件，计算压缩比率
void WriteFile(char* filename, HEAD head, char* pBuffer, int nSize);


