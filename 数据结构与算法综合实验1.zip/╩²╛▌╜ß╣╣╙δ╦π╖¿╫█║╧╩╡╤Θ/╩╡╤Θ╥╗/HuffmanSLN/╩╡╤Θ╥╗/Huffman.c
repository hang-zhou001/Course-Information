#include<stdio.h>  
#include<string.h>  
#include<stdlib.h> 
#include "Huffman.h"

Huffmantree Tree(int *w, int n)
{
	Huffmantree HT, p;
	Mincode code;
	int i, s1, s2;
	int m = 2 * n - 1;
	HT = (Huffmantree)malloc((m + 1) * sizeof(HTnode));
	if (HT == NULL)					//判断内存是否分配成功
		return NULL;
	for (p = HT + 1, i = 1; i <= n; ++i, ++p, w++)
	{
		p->weight = *w;			//为叶子节点赋权值
		p->parent = 0;
		p->lchild = 0;
		p->rchild = 0;
	}
	for (i = n + 1; i <= m; i++, p++)
	{
		p->weight = 0;
		p->parent = 0;
		p->lchild = 0;
		p->rchild = 0;
	}
	for (i = n + 1; i <= m; i++)
	{
		Select(HT, i - 1, &code);
		s1 = code.s1;
		s2 = code.s2;
		HT[s1].parent = i;
		HT[s2].parent = i;
		HT[i].lchild = s1;
		HT[i].rchild = s2;
		HT[i].weight = HT[s1].weight + HT[s2].weight;
	}
	return HT;
}


//用栈进行先序遍历
Huffmancode Huffmancoding(Huffmantree HT, int n, int root)
{
	Huffmancode HC;
	char cd[256];
	Stack s;
	int num = 0;
	HC = (Huffmancode)malloc((n + 1) * sizeof(char*));
	if (HC == NULL )		//判断内存是否分配成功
		return NULL;
	InitStack(&s);
	int p = root;
	int m = 0;
	while (p || StackEmpty(s))
	{
		if (p)					//访问根节点
		{
			Push(&s, p);		//根节点进栈，遍历左子树
			if (HT[p].lchild != 0)
			{
				cd[num++] = '0';
			}
			else if (HT[p].rchild == 0)
			{
				HC[p] = (char*)malloc((num + 1) * sizeof(char));
				if (HC[p] == NULL)
					return NULL;
				cd[num] = '\0';
				strcpy(HC[p], cd);
			
			}
				p = HT[p].lchild;
		}
		else
		{
			Pop(&s, &m);
			if (StackEmpty(s))
			{
				Pop(&s, &p);
				while (p!=0)
				{
					if (HT[m].parent == p)
					{
						num--;
						break;
					}
					else
					{
						num--;
						m = HT[m].parent;
					}
				}
				p = HT[p].rchild;
				if (p != 0)
					cd[num++] = '1';
			}
			else
				p = 0;

			
		}
	}
	free(s.base);
	return HC;

}

//设置标识进行先序遍历求赫夫曼编码
/*Huffmancode Huffmancoding(Huffmantree HT, int n, int root)
{
	
	Huffmancode HC;
	char *cd;
	int num=0;
	HC = (Huffmancode)malloc((n + 1) * sizeof(char*));
	cd = (char*)malloc(n * sizeof(char*));
	if (HC == NULL || cd == NULL)		//判断内存是否分配成功
		return NULL;

	//先序遍历求编码
	for (int i = 1; i < 512; i++)
		HT[i].weight = 0;				//设置状态标记		

	int p = root;
	while (p != 0)
	{
		if (HT[p].weight == 0)
		{
			HT[p].weight = 1;
			if (HT[p].lchild != 0)
			{
				p = HT[p].lchild;
				cd[num++] = '0';
			}
			else if (HT[p].rchild == 0)
			{
				HC[p] = (char*)malloc((num + 1) * sizeof(char));
				cd[num] = '\0';
				strcpy(HC[p], cd);
			}
		}
		else if (HT[p].weight == 1)
		{
			HT[p].weight = 2;
			if (HT[p].rchild != 0)
			{
				p = HT[p].rchild;
				cd[num++] = '1';
			}
		}
		else
		{
			HT[p].weight = 0;
			p = HT[p].parent;
			num--;
		}
	}
	
	free(cd);
	return HC;
}*/


//从叶子到根逆向求每个字符的赫夫曼编码
/*Huffmancode Huffmancoding(Huffmantree HT, int n)
{
	Huffmancode HC;
	char* cd;
	int i, start, f, c;
	HC = (Huffmancode)malloc((n + 1) * sizeof(char*));
	cd = (char*)malloc(n * sizeof(char*));
	cd[n - 1] = '\0';
	for (i = 1; i <= n; i++)
	{
		start = n - 1;
		for (c = i, f = HT[i].parent; f != 0; c = f, f = HT[f].parent)
			if (HT[f].lchild == c)
				cd[--start] = '0';
			else
				cd[--start] = '1';
		HC[i] = (char*)malloc((n - start) * sizeof(char*));
		strcpy(HC[i], &cd[start]);
	}
	free(cd);
	return HC;
}*/

void Select(Huffmantree HT, int n,Mincode*code)
{
	
	int  i, a = INT_MAX, b = INT_MAX;		
	for (i = 1; i <= n; i++)
	{
		if (HT[i].weight < a && HT[i].parent == 0)
		{
			a = HT[i].weight;
			code->s1 = i;
		}
	}
	for (i = 1; i <=n; i++)
	{
		if (HT[i].weight < b && HT[i].parent == 0 && (i != code->s1))
		{
			b = HT[i].weight;
			code->s2 = i;
		}
	}
	
}


void TextHuffTree(Huffmantree pHT)
{
	printf("Byte\t\tWeight\t\tParent\t\tLchild\t\tRchild\n");
	for (int i = 1; i <512; i++)
	{
		printf("pHT[%d]\t\t%d\t\t%d\t\t%d\t\t%d\t\n", i, pHT[i].weight, pHT[i].parent, pHT[i].lchild, pHT[i].rchild);
	}
}



void TestHufCode(int root, Huffmantree pHT, Huffmancode pHC)
{

	if (pHT[root].lchild == 0 && pHT[root].rchild == 0)
	{
		printf("0x%02X %s\n", root-1, pHC[root]);
	}
	if (pHT[root].lchild)
	{
		TestHufCode(pHT[root].lchild, pHT, pHC);
	}
	if (pHT[root].rchild)
	{
		TestHufCode(pHT[root].rchild, pHT, pHC);
	}

}

void Testcode(char *pBuffer)
{
	int b = 0x80;
	for (int i = 0; i < 256; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			b = pBuffer[i] & 0x80;
			if (b == 0x80)
				printf("1");
			else
				printf("0");
			b = 0x80;
			pBuffer[i] = pBuffer[i] << 1;
		}
	}
}

void InitStack(Stack *s)
{
	Stack p;
	p.base = (int*)malloc(512 * sizeof(int));
	if (p.base == NULL)
		return;
	s->base = s->top = p.base;
	s->stacksize = 512;
}


void Push(Stack* s, int e)
{
	*(s->top) = e;
	s->top++;
}

void Pop(Stack* s, int *e)
{
	if (s->top == s->base)			//空栈
		return;
	s->top--;
	*e = *(s->top);
}

int StackEmpty(Stack s)
{
	if (s.base == s.top)
		return false;				//栈为空
	else
		return true;				//栈非空
}



