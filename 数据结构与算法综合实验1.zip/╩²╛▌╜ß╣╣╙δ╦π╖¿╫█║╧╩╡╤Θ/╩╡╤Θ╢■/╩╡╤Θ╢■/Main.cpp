#include<iostream>
#include"Graph.h"
#include"Tourism.h"
using namespace std;
void menu()
{
	cout << "====景区信息管理系统====" << endl;
	cout << "1、创建景区景点图" << endl;
	cout << "2、查询景点信息" << endl;
	cout << "3、旅游景点导航" << endl;
	cout << "4、搜索最短路径" << endl;
	cout << "5、铺设电路规划" << endl;
	cout << "0、退出" << endl;
	cout << "请输入操作编号(0~5):";
}
int main()
{
	int i = 1;
	CreateGraph();
	while (i)
	{
		menu();
		cin >> i;
		switch (i)
		{
		case 1:
			cout << "=====创建景区景点图=====" << endl;
			PrintGraph();
			break;
		case 2:
			cout << "=====查询景点信息=====" << endl;
			GetSpotInfo();
			break;
		case 3:
			cout << "=====旅游景点导航=====" << endl;
			TraverPath();
			break;
		case 4:
			cout << "=====搜索最短路径=====" << endl;
			FindShortPath();
			break;
		case 5:
			cout << "=====铺设电路规划=====" << endl;
			DesignPath();
			break;
		case 0:
			cout << "0、退出" << endl;
			break;
		default:
			cout << "输入的菜单号不符合要求！" << endl;
			break;
		}

	}

}