#pragma once
void CreateGraph();
void PrintGraph();
void GetSpotInfo();		//获取景点信息
void TraverPath();
void FindShortPath();
void DesignPath();


