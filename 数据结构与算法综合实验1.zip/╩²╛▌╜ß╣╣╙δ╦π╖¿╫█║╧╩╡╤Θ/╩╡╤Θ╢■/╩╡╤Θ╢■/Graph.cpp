#include"Graph.h"
#include<string.h>
#include<iostream>

using namespace std;

//初始化图
void CGraph::Init()
{
	m_n_VexNum = 0;
	for (int i = 0; i < 20; i++)
	{
		strcpy(m_aVexs[i].desc, "");
		strcpy(m_aVexs[i].name, "");
		m_aVexs->num = -1;
		for (int j = 0; j < 20; j++)
			m_aAdjMatrix[i][j] = 0;
	}
}

//插入结点信息
bool CGraph::InsertVex(Vex sVex)
{
	if (m_n_VexNum == MAX_VERTEX_NUM)
	{
		return false;
	}
	m_aVexs[m_n_VexNum++] = sVex;
	return true;
}

//插入边的信息
bool CGraph::InsertEdge(Edge sEdge)
{
	if (sEdge.vex1 < 0 || sEdge.vex1 >= m_n_VexNum || sEdge.vex2 < 0 || sEdge.vex2 >= m_n_VexNum)
	{
		return false;
	}
	m_aAdjMatrix[sEdge.vex1][sEdge.vex2] = sEdge.weight;
	m_aAdjMatrix[sEdge.vex2][sEdge.vex1] = sEdge.weight;
	return true;
}

//输出结点和边的信息
void CGraph::print()
{
	cout << "顶点数目：" << m_n_VexNum << endl;
	cout << "-----顶点-----" << endl;
	for (int i = 0; i < m_n_VexNum; i++)
	{
		cout << m_aVexs[i].num << "-" << m_aVexs[i].name << endl;
	}
	cout << "-----边-----" << endl;
	for (int i = 0; i < m_n_VexNum; i++)
	{
		for (int j = i; j < m_n_VexNum; j++)
		{
			if (m_aAdjMatrix[i][j] != 0)
			{
				cout << "<" << i << "," << j << ">" << m_aAdjMatrix[i][j] << endl;
			}
		}
	}
}

//获取编号对应的结点
Vex CGraph::GetVex(int i)
{
	return m_aVexs[i];
}

//获取连接编号对应的结点的边的信息
int CGraph::FindEdge(int v, Edge sEdge[])
{
	int k = 0;
	for (int i = 0; i < m_n_VexNum; i++)
	{
		if (m_aAdjMatrix[v][i] != 0)
		{
			sEdge[k].vex1 = v;
			sEdge[k].vex2 = i;
			sEdge[k].weight = m_aAdjMatrix[v][i];
			k++;
		}
	}
	return k;
}

//深度优先遍历
void CGraph::DFS(int nVex, bool bVisit[], int& index, PathList& pList)
{

	bVisit[nVex] = true;			//设置起始点已经访问
	pList->vexs[index++] = nVex;	//将该编号加入路线中

	//如果已经访问了全部景点编号，则保存一条路径，同时生成下一条路径
	if (index == m_n_VexNum)
	{
		pList->vexs[index] = -1;
		pList->next = (PathList)malloc(sizeof(Path));
		if (pList->next == NULL) return;
		for (int c = 0; c < m_n_VexNum; c++)
		{
			pList->next->vexs[c] = pList->vexs[c];
		}
		pList = pList->next;
		pList->next = NULL;
	}
	else
	{
		for (int i = 0; i < m_n_VexNum; i++)
		{
			if (m_aAdjMatrix[nVex][i] != 0 && !bVisit[i])
			{
				DFS(i, bVisit, index, pList);

				//回溯，退回到上一结点
				bVisit[i] = false;
				index--;
			}
		}
	}
}

void CGraph::DFSTraverse(int nVex, PathList& pList)
{
	int index = 0;
	bool bVisit[10] = { false };	//标识数组，标识编号是否已经访问
	DFS(nVex, bVisit, index, pList);	//深度优先遍历
}

//查找最短路径（迪杰斯特拉算法）
int CGraph::FindShortPath(int nVexStart, int nVexEnd, Edge aPath[])
{
	bool bVisit[10] = { false };		//判断结点是否为最短路径上的点
	int pre[10];			//存放前置结点
	int dist[20];			//存放各点到起始点的距离
	//将各点到nVexStart的距离储存在dist中
	for (int i = 0; i < m_n_VexNum; i++)
	{
		pre[i] = nVexStart;
		if (m_aAdjMatrix[nVexStart][i] != 0)
		{
			dist[i] = m_aAdjMatrix[nVexStart][i];
		}
		else
		{
			dist[i] = INT_MAX;
		}
	}

	int k;
	bVisit[nVexStart] = true;

	int min;
	int tem;
	//查找最短路径的其余n-1个点
	for (int i = 0; i < m_n_VexNum - 1; i++)
	{
		min = INT_MAX;
		for (int j = 0; j < m_n_VexNum; j++)
		{
			if (min > dist[j] && !bVisit[j])
			{
				min = dist[j];
				k = j;
			}
		}
		bVisit[k] = true;
		if (k == nVexEnd)
			break;
		//更新最短路径
		for (int p = 0; p < m_n_VexNum; p++)
		{
			if (m_aAdjMatrix[k][p] == 0)
				tem = INT_MAX;
			else
				tem = min + m_aAdjMatrix[k][p];
			if (!bVisit[p] && tem < dist[p])
			{
				dist[p] = min + m_aAdjMatrix[k][p];
				pre[p] = k;
			}
		}

	}


	int Num = 0; //总共Num条路径
	int i = nVexEnd;//从终点开始回溯
	while (i != nVexStart)
	{
		aPath[Num].vex2 = i;
		aPath[Num].vex1 = pre[i];
		aPath[Num].weight = m_aAdjMatrix[pre[i]][i];
		i = pre[i];
		Num++;
	}
	return Num;
}

//构建最小生成树（prim算法）
int CGraph::FindMinTree(Edge aPath[])
{
	bool bVisit[10] = { false };	//标识数组
	int dist[10][10];				//存储任意两个结点之间的路径长度

	//dist数组赋值
	for (int i = 0; i < m_n_VexNum; i++)
	{
		for (int j = i; j < m_n_VexNum; j++)
		{
			if (m_aAdjMatrix[i][j] == 0)
			{
				dist[i][j] = INT_MAX;
				dist[j][i] = INT_MAX;
			}
			else
			{
				dist[i][j] = m_aAdjMatrix[i][j];
				dist[j][i] = m_aAdjMatrix[j][i];
			}
		}
	}
	//从A景区开始铺设电路
	bVisit[0] = true;
	int a, b, min;
	//找出其余n-1条边
	for (int i = 0; i < m_n_VexNum - 1; i++)
	{
		min = INT_MAX;
		for (int p = 0; p < m_n_VexNum; p++)
		{
			if (bVisit[p])
				for (int q = 0; q < m_n_VexNum; q++)
				{
					if (!bVisit[q])
						if (min > dist[p][q])
						{
							min = dist[p][q];
							a = p;
							b = q;
						}
				}
		}
		bVisit[b] = true;
		//获取边的信息
		aPath[i].vex1 = a;
		aPath[i].vex2 = b;
		aPath[i].weight = m_aAdjMatrix[a][b];
	}
	return 0;
}

