#pragma once
#define MAX_VERTEX_NUM 20
#include<stdio.h>

//存储结点信息
typedef struct Vex		//图的结点存储结构
{
	int num;			//结点（景区）数量
	char name[20];		//景区名称
	char desc[1024];	//说明
}Vex;

//存储边的信息
typedef struct Edge		//图的边存储结构
{
	//边两端结点
	int vex1;			
	int vex2;
	int weight;			//结点权值
}Edge;

//存储路径信息
typedef struct Path		
{
	int vexs[20];		//存储一条路径
	struct Path* next;
}*PathList, Path;

class CGraph
{
private:
	int m_aAdjMatrix[20][20];			//邻接矩阵
	Vex m_aVexs[20];					//节点信息
	int m_n_VexNum;						//节点个数
public:
	void Init();				//初始化图
	bool InsertVex(Vex sVex);	//插入景点信息
	bool InsertEdge(Edge sEdge);	//插入路径信息
	void print();					//打印景点信息
	Vex GetVex(int i);				//获取目标景点信息
	int FindEdge(int v, Edge sEdge[]);	//获取周边路径信息
	void DFS(int nVex, bool bVisit[], int& index, PathList& pList);  //深度优先遍历图
	void DFSTraverse(int nVex, PathList& p);						//深度优先遍历
	int FindShortPath(int nVexStart, int nVexEnd, Edge aPath[]);	//搜索最短路径
	int FindMinTree(Edge aPath[]);							//最小生成树
};