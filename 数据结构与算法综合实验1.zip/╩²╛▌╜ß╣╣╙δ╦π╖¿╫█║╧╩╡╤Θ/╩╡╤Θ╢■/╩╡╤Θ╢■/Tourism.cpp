#include"Graph.h"
#include"Tourism.h"
#include<stdio.h>
#include<iostream>
using namespace std;

CGraph m_Graph;

//创建景区
void CreateGraph()
{
	m_Graph.Init();
	Vex sVex = { 0,"","" };
	Edge sEdge = { 0,0,0 };
	FILE* fp = fopen("Vex.txt", "r");
	while (!feof(fp))
	{
		//读取结点信息
		(void)fscanf(fp, "%d", &sVex.num);
		(void)fscanf(fp, "%s", sVex.name);
		(void)fscanf(fp, "%s", sVex.desc);
		m_Graph.InsertVex(sVex);
	}
	fclose(fp);
	fp = fopen("Edge.txt", "r");
	while (!feof(fp))
	{
		//读取边的信息
		(void)fscanf(fp, "%d %d %d", &sEdge.vex1, &sEdge.vex2, &sEdge.weight);
		m_Graph.InsertEdge(sEdge);
	}
	fclose(fp);

}

//输出景区信息
void PrintGraph()
{
	m_Graph.print();
}

//获取景点信息
void GetSpotInfo()
{
	int num1, num2;
	char c[20];
	Vex sVex;
	cout << "请输入想要查询的景点编号：";
	cin >> num1;

	//判断输入编号是否存在
	if (num1 < 0 || num1>6)
	{
		cout << "输入景区编号不存在！" << endl;
		return;
	}

	sVex = m_Graph.GetVex(num1);		//根据编号获取结点信息
	cout << sVex.name << endl;
	strcpy(c, sVex.name);
	cout << sVex.desc << endl;
	cout << "----周边景区----" << endl;
	Edge sEdge[10];
	num2 = m_Graph.FindEdge(num1, sEdge);
	for (int i = 0; i < num2; i++)
	{
		sVex = m_Graph.GetVex(sEdge[i].vex2);
		cout << c << "->" << sVex.name << sEdge[i].weight << "m" << endl;
	}
}

//景区路线导航
void TraverPath()
{
	int num;
	int i = 0;
	cout << "请输入起始点编号:";
	cin >> num;

	//判断输入编号是否存在
	if (num < 0 || num>6)
	{
		cout << "输入景区编号不存在！" << endl;
		return;
	}

	Vex sVex;
	PathList path = (PathList)malloc(sizeof(Path));
	if (path == NULL)
		return;
	path->next = NULL;
	PathList p = path;
	m_Graph.DFSTraverse(num, path);		//进行深度优先遍历
	path = p;
	cout << "导游路线为：" << endl;
	while (path->next != NULL)
	{
		i = 0;
		while (path->vexs[i] != -1)		//判断一条路径是否输出完毕
		{
			sVex = m_Graph.GetVex(path->vexs[i]);	//获取结点信息
			//输出路线
			if (path->vexs[i + 1] != -1)
				cout << sVex.name << "->";
			else
				cout << sVex.name << endl;
			i++;

		}
		path = path->next;
	}
	free(path);//释放结点
}

//查找最短路径
void FindShortPath()
{
	int nVexStart, nVexEnd;
	cout << "输入起点编号：";
	cin >> nVexStart;
	cout << "输入终点编号：";
	cin >> nVexEnd;
	//判断输入编号是否存在
	if (nVexStart < 0 || nVexStart>6 || nVexEnd < 0 || nVexEnd>6)
	{
		cout << "输入景区编号不存在！" << endl;
		return;
	}
	if (nVexStart ==nVexEnd)
	{
		cout << "起点终点编号不能相同！" << endl;
		return;
	}
	Edge aPath[10];
	Vex sVex;
	int num = m_Graph.FindShortPath(nVexStart, nVexEnd, aPath);
	int weight = 0;
	cout << "最短路线：";
	for (int i = num - 1; i >= 0; i--)
	{

		sVex = m_Graph.GetVex(aPath[i].vex1);
		cout << sVex.name << "->";
		weight += aPath[i].weight;
	}
	sVex = m_Graph.GetVex(aPath[0].vex2);
	cout << sVex.name << endl;
	cout << "最短距离：" << weight << endl;
}


//铺设电路规划
void DesignPath()
{
	Edge aPath[10];
	m_Graph.FindMinTree(aPath);
	int weight = 0;
	Vex sVex;
	for (int i = 0; i <= 5; i++)
	{
		sVex = m_Graph.GetVex(aPath[i].vex1);
		cout << sVex.name << "->";
		sVex = m_Graph.GetVex(aPath[i].vex2);
		cout << sVex.name << " " << aPath[i].weight << "m" << endl;
		weight += aPath[i].weight;
	}
	cout << "铺设电路总长为：" << weight << endl;
}
